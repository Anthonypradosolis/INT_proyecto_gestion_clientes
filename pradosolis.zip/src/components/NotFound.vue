<template>
    <div class="row">
        <div class="col-12 text-center">
            <h1 class="display-1">404</h1>
            <img src="@/assets/homer-error.png" alt="404 Error" class="mb-4" />
            <br></br>
            <h2 class="mb-4">Página No Encontrada</h2>
            <p class="mb-4">Perdona nos hemos equivocado.</p>
            <router-link to="/" class="btn btn-primary">Ir a Inicio</router-link>
        </div>
    </div>
</template>
<script setup>
</script>
<style scoped>
</style>