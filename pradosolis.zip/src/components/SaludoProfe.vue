<script setup>


</script>


<template>
    <h1>Hola profe</h1>
</template>
<style scoped>
    h1 {
        color: blue;
    }
</style>    