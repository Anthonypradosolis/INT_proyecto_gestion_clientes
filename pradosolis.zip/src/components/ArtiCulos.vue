<template>
{
  "_id": {
    "$oid": "6909ba4d13491a28d55ff70b"
  },
  "tipo": "coche",
  "marca": "Toyota",
  "modelo": "Corolla",
  "anio": 2019,
  "kilometros": 73500,
  "precio": 13500,
  "combustible": "gasolina",
  "transmision": "manual",
  "color": "gris plata",
  "puertas": 5,
  "potencia_cv": 122,
  "descripcion": "Toyota Corolla 2019 en muy buen estado, único propietario, revisiones al día.",
  "ubicacion": {
    "ciudad": "Santiago de Compostela",
    "provincia": "A Coruña"
  },
  "contacto": {
    "nombre": "Juan Pérez",
    "telefono": "+34 612 345 678",
    "email": "juan.perez@example.com"
  },
  "fecha_publicacion": {
    "$date": "2025-11-04T00:00:00.000Z"
  },
  "estado": "disponible"
}
</template>
<script>
</script>
<style>
</style>